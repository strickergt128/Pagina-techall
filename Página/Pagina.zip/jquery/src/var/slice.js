define([
	"./arr"
], function( arr ) {
	return arr.slice;
});
